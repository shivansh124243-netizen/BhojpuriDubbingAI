#!/usr/bin/env python3
"""Local HTTP bridge for the Android client.
Run this on the same PC/device that has the local AI models installed.
No paid/cloud API is required.
"""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import json, os, subprocess, threading, uuid, urllib.parse

ROOT = Path(os.getenv('DUB_WORK_ROOT','jobs')).resolve(); ROOT.mkdir(parents=True, exist_ok=True)
JOBS = {}; LOCK = threading.Lock()
BASE = Path(__file__).resolve().parents[1]


def json_send(h, code, obj):
    raw=json.dumps(obj, ensure_ascii=False).encode(); h.send_response(code)
    h.send_header('Content-Type','application/json; charset=utf-8'); h.send_header('Content-Length',str(len(raw))); h.end_headers(); h.wfile.write(raw)


def launch(job_id, payload):
    wd=ROOT/job_id; wd.mkdir(parents=True, exist_ok=True)
    inp=wd/'input.mp4'; out=wd/'dubbed.mp4'
    env=os.environ.copy(); env['BHOJPURI_VOICE']=payload.get('voice','Bhojpuri (Male)')
    cmd=['python','-m','pipeline.dub_movie',str(inp),str(out),'--work',str(wd)]
    proc=subprocess.Popen(cmd, cwd=str(BASE), env=env)
    with LOCK: JOBS[job_id]=proc


class H(BaseHTTPRequestHandler):
    def body_bytes(self):
        n=int(self.headers.get('Content-Length','0') or 0); return self.rfile.read(n)
    def do_POST(self):
        if self.path.startswith('/upload'):
            q=urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
            jid=uuid.uuid4().hex[:12]; wd=ROOT/jid; wd.mkdir(parents=True, exist_ok=True)
            (wd/'input.mp4').write_bytes(self.body_bytes())
            voice=(q.get('voice') or ['Bhojpuri (Male)'])[0]
            threading.Thread(target=launch,args=(jid,{'voice':voice}),daemon=True).start()
            json_send(self,202,{'job_id':jid}); return
        if self.path.startswith('/pause/') or self.path.startswith('/resume/'):
            jid=self.path.split('/')[-1]; flag=ROOT/jid/'PAUSE'
            if self.path.startswith('/pause/'): flag.touch(); action='paused'
            else: flag.unlink(missing_ok=True); action='resumed'
            json_send(self,200,{'job_id':jid,'state':action}); return
        json_send(self,404,{'error':'not found'})
    def do_GET(self):
        if self.path.startswith('/status/'):
            jid=self.path.split('/')[-1]; p=ROOT/jid/'status.json'
            data=json.loads(p.read_text(encoding='utf-8')) if p.exists() else {'state':'starting','progress':0}
            proc=JOBS.get(jid); data['process_alive']=bool(proc and proc.poll() is None)
            json_send(self,200,data); return
        if self.path.startswith('/download/'):
            jid=self.path.split('/')[-1]; f=ROOT/jid/'dubbed.mp4'
            if not f.exists(): json_send(self,404,{'error':'output not ready'}); return
            size=f.stat().st_size; self.send_response(200); self.send_header('Content-Type','video/mp4'); self.send_header('Content-Length',str(size)); self.end_headers()
            with f.open('rb') as r:
                while True:
                    b=r.read(1024*1024)
                    if not b: break
                    self.wfile.write(b)
            return
        json_send(self,404,{'error':'not found'})
    def log_message(self,*args): pass

if __name__=='__main__':
    port=int(os.getenv('DUB_PORT','8765')); print(f'Listening on 0.0.0.0:{port}', flush=True)
    ThreadingHTTPServer(('0.0.0.0',port),H).serve_forever()
