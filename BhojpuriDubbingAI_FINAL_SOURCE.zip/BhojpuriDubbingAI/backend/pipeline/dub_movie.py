#!/usr/bin/env python3
"""Offline/local Hindi -> Bhojpuri movie dubbing pipeline.

Pipeline: chunk -> Hindi ASR -> Bhojpuri translation -> local TTS -> timestamp mix -> concat.
All progress is checkpointed so an interrupted run can continue without redoing finished chunks.
"""
import argparse, json, os, subprocess, shutil, time
from pathlib import Path


def run(cmd):
    print(">", " ".join(map(str, cmd)), flush=True)
    subprocess.run(cmd, check=True)


def probe_duration(path):
    out = subprocess.check_output([
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", str(path)
    ], text=True)
    return float(out.strip())


def write_status(work, **values):
    work.mkdir(parents=True, exist_ok=True)
    p = work / "status.json"
    old = {}
    if p.exists():
        try: old = json.loads(p.read_text(encoding="utf-8"))
        except Exception: pass
    old.update(values, updated_at=time.time())
    p.write_text(json.dumps(old, ensure_ascii=False, indent=2), encoding="utf-8")


def chunk_video(src, outdir, minutes):
    outdir.mkdir(parents=True, exist_ok=True)
    existing = sorted(outdir.glob("chunk_*.mp4"))
    if existing:
        return existing
    run(["ffmpeg", "-y", "-i", str(src), "-map", "0", "-c", "copy",
         "-f", "segment", "-segment_time", str(minutes * 60),
         "-reset_timestamps", "1", str(outdir / "chunk_%04d.mp4")])
    return sorted(outdir.glob("chunk_*.mp4"))


class LocalTranslator:
    def __init__(self):
        import requests
        self.requests = requests
        self.url = os.getenv("LOCAL_TRANSLATOR_URL", "http://127.0.0.1:11434/api/generate")
        self.model = os.getenv("LOCAL_TRANSLATOR_MODEL", "qwen2.5:3b")

    def translate(self, text):
        prompt = (
            "Translate Hindi movie dialogue into natural spoken Bhojpuri. "
            "Keep the speaker's meaning, names, emotion and register. "
            "Use conversational Bhojpuri, not formal Hindi. Output only the translation.\n\n" + text
        )
        if "11434" in self.url:
            r = self.requests.post(self.url, json={"model": self.model, "prompt": prompt, "stream": False}, timeout=600)
            r.raise_for_status()
            return r.json().get("response", "").strip()
        r = self.requests.post(self.url, json={"text": prompt}, timeout=600)
        r.raise_for_status()
        return r.json()["text"].strip()


class LocalTTS:
    def __init__(self):
        self.voice = os.getenv("BHOJPURI_VOICE", "Bhojpuri (Male)")
        self.use_svara = os.getenv("USE_SVARA", "1") == "1"
        self._synth = None

    def synthesize(self, text, outwav):
        if self.use_svara:
            from svara_tts import synthesize
            synthesize(text, str(outwav), self.voice)
            return
        import requests
        url = os.getenv("LOCAL_TTS_URL", "http://127.0.0.1:8000/synthesize")
        r = requests.post(url, json={"text": text, "voice": self.voice, "format": "wav"}, timeout=600)
        r.raise_for_status()
        outwav.write_bytes(r.content)


def transcribe(chunk, model, work, asr_model_name):
    p = work / "segments.json"
    if p.exists():
        return json.loads(p.read_text(encoding="utf-8"))
    from faster_whisper import WhisperModel
    segs, _ = model.transcribe(str(chunk), language="hi", vad_filter=True, word_timestamps=False)
    data = [{"start": float(s.start), "end": float(s.end), "text": s.text.strip()}
            for s in segs if s.text.strip()]
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return data


def fit_audio(src, target, out):
    dur = probe_duration(src)
    ratio = dur / max(target, 0.15)
    if 0.65 <= ratio <= 1.60:
        # atempo accepts 0.5..2.0; ratio >1 means source is longer and must speed up.
        run(["ffmpeg", "-y", "-i", str(src), "-filter:a", f"atempo={ratio:.6f}", str(out)])
    else:
        shutil.copy2(src, out)


def mix_timestamped(chunk, segments, work, out, chunk_duration):
    if not segments:
        shutil.copy2(chunk, out)
        return
    wavs = []
    tts = LocalTTS()
    for i, s in enumerate(segments):
        raw = work / f"tts_{i:05d}.wav"
        fitted = work / f"fit_{i:05d}.wav"
        if not fitted.exists():
            tts.synthesize(s["bhojpuri"], raw)
            fit_audio(raw, max(0.15, s["end"] - s["start"]), fitted)
        wavs.append((s, fitted))
    inputs = []
    filters = []
    labels = []
    for i, (s, wav) in enumerate(wavs):
        inputs += ["-i", str(wav)]
        label = f"a{i}"
        delay = max(0, int(round(float(s["start"]) * 1000)))
        filters.append(f"[{i}:a]adelay={delay}:all=1[{label}]")
        labels.append(f"[{label}]")
    filters.append("".join(labels) + f"amix=inputs={len(labels)}:duration=longest:normalize=0,atrim=0:{chunk_duration:.3f}[dub]")
    mixed = work / "timestamped.wav"
    if not mixed.exists():
        run(["ffmpeg", "-y", *inputs, "-filter_complex", ";".join(filters),
             "-map", "[dub]", "-ar", "24000", "-ac", "1", str(mixed)])
    run(["ffmpeg", "-y", "-i", str(chunk), "-i", str(mixed),
         "-map", "0:v:0", "-map", "1:a:0", "-c:v", "copy", "-c:a", "aac",
         "-t", f"{chunk_duration:.3f}", str(out)])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("--work", default="work")
    ap.add_argument("--chunk-minutes", type=int, default=15)
    ap.add_argument("--whisper", default="small")
    args = ap.parse_args()
    src = Path(args.input).resolve(); out = Path(args.output).resolve(); work = Path(args.work).resolve()
    work.mkdir(parents=True, exist_ok=True)
    write_status(work, state="starting", input=str(src), output=str(out))
    chunks = chunk_video(src, work / "chunks", args.chunk_minutes)
    total = len(chunks)
    write_status(work, state="processing", total_chunks=total, completed_chunks=0)

    from faster_whisper import WhisperModel
    asr = WhisperModel(args.whisper, device="auto", compute_type="auto")
    translator = LocalTranslator()
    results = []

    for n, ch in enumerate(chunks):
        while (work / "PAUSE").exists():
            write_status(work, state="paused", current_chunk=n + 1, completed_chunks=n, progress=int(n * 100 / total))
            time.sleep(2)
        cw = work / f"part_{n:04d}"; cw.mkdir(exist_ok=True)
        marker = cw / "done.json"
        if marker.exists():
            results.append(Path(json.loads(marker.read_text(encoding="utf-8"))["output"]))
            write_status(work, current_chunk=n + 1, completed_chunks=n + 1, progress=int((n + 1) * 100 / total))
            continue
        cdur = probe_duration(ch)
        segs = transcribe(ch, asr, cw, args.whisper)
        tp = cw / "translated.json"
        if tp.exists():
            segs = json.loads(tp.read_text(encoding="utf-8"))
        else:
            for s in segs:
                s["bhojpuri"] = translator.translate(s["text"])
            tp.write_text(json.dumps(segs, ensure_ascii=False, indent=2), encoding="utf-8")
        outpart = cw / "dubbed.mp4"
        if not outpart.exists():
            mix_timestamped(ch, segs, cw, outpart, cdur)
        marker.write_text(json.dumps({"output": str(outpart)}, ensure_ascii=False), encoding="utf-8")
        results.append(outpart)
        write_status(work, current_chunk=n + 1, completed_chunks=n + 1, progress=int((n + 1) * 100 / total))

    concat = work / "final.txt"
    concat.write_text("\n".join("file '" + p.as_posix().replace("'", "'\\''") + "'" for p in results), encoding="utf-8")
    run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat), "-c", "copy", str(out)])
    write_status(work, state="done", progress=100, final=str(out))
    print("DONE:", out)

if __name__ == "__main__":
    main()
