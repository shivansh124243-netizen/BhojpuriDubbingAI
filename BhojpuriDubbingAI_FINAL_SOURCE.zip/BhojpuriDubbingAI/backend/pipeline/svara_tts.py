#!/usr/bin/env python3
"""Local Svara-TTS adapter. No paid API. Requires the Svara model locally."""
import os
import torch
import soundfile as sf
from transformers import pipeline

_MODEL = os.getenv('SVARA_MODEL','ankurbanik/svara-tts-v1')
_PIPE = None

def _pipe():
    global _PIPE
    if _PIPE is None:
        _PIPE = pipeline('text-to-speech', model=_MODEL, device=0 if torch.cuda.is_available() else -1)
    return _PIPE

def synthesize(text, out_path, voice='Bhojpuri (Male)'):
    # The Svara model uses speaker identities such as Bhojpuri (Male)/(Female).
    result = _pipe()(text, speaker=voice)
    audio = result['audio']
    if hasattr(audio, 'squeeze'):
        audio = audio.squeeze()
    sf.write(out_path, audio, result.get('sampling_rate', 24000))
