## पूरा flow

Android → persistent WorkManager → local processing service → chunk queue → Hindi ASR → Hindi→Bhojpuri local translation → natural Bhojpuri TTS → timestamped audio → FFmpeg mux → checkpoint → final MP4.

### Natural voice
Svara-TTS और अन्य open Bhojpuri TTS models male/female Bhojpuri voices और style/emotion controls उपलब्ध कराते हैं। मॉडल की license/terms को deployment से पहले जांचें।

### 3 घंटे
15-minute chunks का default = लगभग 12 chunks. हर chunk के बाद checkpoint लिखा जाता है। इससे पूरा काम एक ही बार RAM में नहीं रखना पड़ता।

### Background
Android Activity बंद होने पर job WorkManager में रहती है। Phone power-off होने पर processing रुकती है; reboot के बाद queued/checkpointed काम resume कराया जा सकता है।
