# Bhojpuri Dubbing AI v7

Free/local source project for Hindi-video → Bhojpuri dubbing.

## Included
- Android video picker and progress UI
- Long-running WorkManager worker with foreground notification
- Upload to configurable local AI bridge
- 15-minute chunking with checkpoint/resume
- Hindi ASR using faster-whisper
- Local Hindi→Bhojpuri translation through Ollama-compatible endpoint
- Bhojpuri TTS adapter using Svara-TTS speaker selection
- Timestamped TTS placement and FFmpeg video/audio muxing
- Pause checkpoint flag and status endpoint
- Final MP4 download into Android Movies/BhojpuriDubbing
- No paid API requirement

## Important
This is not a standalone phone-only APK. The AI bridge must run on a device/computer reachable by the Android phone. A truly standalone APK would require packaging compatible ASR, translation and Bhojpuri TTS models/runtime into Android and is a separate build/testing step.
