package com.example.bhojpuridubbingai

import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Notification
import android.os.Build
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.delay
import java.net.HttpURLConnection
import java.net.URL

class DubbingWorker(private val ctx: Context, p: WorkerParameters): CoroutineWorker(ctx,p) {
    private val base get() = inputData.getString("server")!!.trimEnd('/')
    private fun fg(progress:Int, text:String):ForegroundInfo {
        val nm=ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(NotificationChannel("dub","Bhojpuri Dubbing",NotificationManager.IMPORTANCE_LOW))
        val n=NotificationCompat.Builder(ctx,"dub").setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle("Bhojpuri Dubbing AI").setContentText(text).setProgress(100,progress,false).setOngoing(true).build()
        return ForegroundInfo(1001,n)
    }
    override suspend fun doWork():Result {
        setForeground(fg(0,"Video upload ho raha hai…"))
        val uri=Uri.parse(inputData.getString("uri")!!); val voice=inputData.getString("voice") ?: "Bhojpuri (Male)"
        val conn=URL("$base/upload?voice="+java.net.URLEncoder.encode(voice,"UTF-8")).openConnection() as HttpURLConnection
        conn.requestMethod="POST"; conn.doOutput=true; conn.setRequestProperty("Content-Type","video/mp4")
        ctx.contentResolver.openInputStream(uri)!!.use { input -> conn.outputStream.use { out -> val b=ByteArray(1024*1024); while(true){val n=input.read(b); if(n<0) break; out.write(b,0,n)} } }
        if(conn.responseCode !in 200..299) return Result.retry()
        val job=org.json.JSONObject(conn.inputStream.bufferedReader().readText()).getString("job_id")
        while(true){
            if(isStopped) return Result.retry()
            val s=URL("$base/status/$job").openStream().bufferedReader().readText(); val j=org.json.JSONObject(s)
            val pct=j.optInt("progress",0); val state=j.optString("state","processing")
            setProgress(workDataOf("p" to pct,"status" to state,"job" to job)); setForeground(fg(pct,state))
            if(state=="done") break
            delay(3000)
        }
        val outName="Bhojpuri_${System.currentTimeMillis()}.mp4"; val out=ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, android.content.ContentValues().apply{put(MediaStore.Video.Media.DISPLAY_NAME,outName);put(MediaStore.Video.Media.MIME_TYPE,"video/mp4"); if(Build.VERSION.SDK_INT>=29) put(MediaStore.Video.Media.RELATIVE_PATH,"Movies/BhojpuriDubbing")}) ?: return Result.failure()
        ctx.contentResolver.openOutputStream(out)!!.use { os -> URL("$base/download/$job").openStream().use { it.copyTo(os,1024*1024) } }
        return Result.success(workDataOf("status" to "डबिंग पूरी हुई", "output" to outName))
    }
}
