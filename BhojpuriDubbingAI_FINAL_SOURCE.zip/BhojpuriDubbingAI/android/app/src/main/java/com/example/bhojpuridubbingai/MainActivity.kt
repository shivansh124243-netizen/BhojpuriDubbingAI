package com.example.bhojpuridubbingai

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.*
import androidx.work.*
import java.util.concurrent.TimeUnit

class MainActivity:Activity(){
    private lateinit var n:TextView; private lateinit var p:ProgressBar; private lateinit var s:TextView
    private var uri:android.net.Uri?=null
    override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main)
        n=findViewById(R.id.name);p=findViewById(R.id.progress);s=findViewById(R.id.status)
        findViewById<Spinner>(R.id.voice).adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("Bhojpuri (Male)","Bhojpuri (Female)"))
        findViewById<Button>(R.id.select).setOnClickListener{startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="video/*";addCategory(Intent.CATEGORY_OPENABLE) },9)}
        findViewById<Button>(R.id.start).setOnClickListener{startJob()}
        findViewById<Button>(R.id.pause).setOnClickListener{toast("Pause checkpoint server par chunk ke baad apply hoga")}
    }
    private fun startJob(){
        val u=uri ?: run{toast("पहले वीडियो चुनिए");return}; val voice=findViewById<Spinner>(R.id.voice).selectedItem.toString()
        val server=findViewById<EditText>(R.id.server).text.toString().ifBlank{"http://192.168.1.10:8765"}
        val req=OneTimeWorkRequestBuilder<DubbingWorker>().setInputData(workDataOf("uri" to u.toString(),"voice" to voice,"server" to server)).setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
        WorkManager.getInstance(this).enqueueUniqueWork("movie-dubbing",ExistingWorkPolicy.REPLACE,req)
        WorkManager.getInstance(this).getWorkInfoByIdLiveData(req.id).observe(this){w->p.progress=w.progress.getInt("p",0);s.text=w.progress.getString("status")?:w.state.name; if(w.state==WorkInfo.State.SUCCEEDED) toast("Final video Movies/BhojpuriDubbing में save हो गया")}
    }
    override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d);if(r==9&&c==RESULT_OK)d?.data?.let{u->uri=u;contentResolver.takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);contentResolver.query(u,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use{x->if(x.moveToFirst())n.text=x.getString(0)}}}
    private fun toast(t:String)=Toast.makeText(this,t,Toast.LENGTH_SHORT).show()
}
